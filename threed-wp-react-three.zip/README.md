# threed-wp-react-three
Embed a Three.js React-Three-Fiber canvas in a WordPress page using a shortcode
